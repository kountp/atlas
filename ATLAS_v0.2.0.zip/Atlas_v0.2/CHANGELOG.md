# Changelog

## 0.2.0

- Added PostgreSQL persistence.
- Added ASP.NET Core Identity and JWT authentication.
- Added refresh-token rotation foundation.
- Added role seeding and development administrator.
- Added Companies and Customers CRUD endpoints.
- Added audit fields, optimistic version field and soft delete.
- Added Swagger bearer authentication, Serilog, health checks and Docker Compose.
