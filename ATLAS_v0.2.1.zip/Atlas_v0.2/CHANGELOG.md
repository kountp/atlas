# Changelog

## 0.2.0

- Added PostgreSQL persistence.
- Added ASP.NET Core Identity and JWT authentication.
- Added refresh-token rotation foundation.
- Added role seeding and development administrator.
- Added Companies and Customers CRUD endpoints.
- Added audit fields, optimistic version field and soft delete.
- Added Swagger bearer authentication, Serilog, health checks and Docker Compose.

## 0.2.1 - Work Orders foundation
- Added work-order aggregate with scheduling, technician assignment, GPS check-in/check-out, tasks, parts and customer signature.
- Added EF Core configurations and indexes.
- Added lifecycle validation for completion and cancellation.
